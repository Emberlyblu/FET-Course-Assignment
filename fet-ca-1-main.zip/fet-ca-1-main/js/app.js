var typed = new Typed('.aboutMe', {
  strings: ['<Student Name>', 'The code master', '', 'always working to be the best backend developer'],
  smartBackspace: true,
  typeSpeed: 100,
  backSpeed: 100,
  loop: true,
  loopCount: Infinity,
  startDelay: 1000,
});
